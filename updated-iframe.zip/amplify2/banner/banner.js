
// jarallax
jarallax(document.querySelectorAll('.jarallax'), {
    // speed: 0.2,
    noAndroid: false, 
    noIos: false
});

// jarallax end

