
var siteCarousel = function () {
    
    if ( $('.nonloop-block-14').length > 0 ) {
      $('.nonloop-block-14').owlCarousel({
        center: false,
        items: 1,
        loop: true,
        stagePadding: 0,
        margin: 0,
        autoplay: true,
        nav: true,
        navText: ['<span class="icon-arrow_back">', '<span class="icon-arrow_forward">'],
        responsive:{
          600:{
            margin: 20,
            nav: true,
            items: 2
          },
          1000:{
            margin: 30,
            stagePadding: 0,
            nav: true,
            items: 3
          },
          1200:{
            margin: 30,
            stagePadding: 0,
            nav: true,
            items: 3
          }
        }
      });
    }

    $('.slide-one-item').owlCarousel({
      center: false,
      items: 1,
      loop: true,
      stagePadding: 0,
      margin: 0,
      autoplay: true,
      pauseOnHover: false,
      nav: true,
      navText: ['<span class="icon-keyboard_arrow_left">', '<span class="icon-keyboard_arrow_right">']
    });
  };
  siteCarousel();