

// main_menu stiky
$(window).scroll(function() {    
    var scroll = $(window).scrollTop();

     //>=, not <=
    if (scroll >= 20) {
        //clearHeader, not clearheader - caps H
        $(".main_menu").addClass("is_sticky");
        $(".main_menu").addClass("dy_background-gradient");
    }else
    {
        $(".main_menu").removeClass("is_sticky");
        $(".main_menu").removeClass("dy_background-gradient");
    }
});

$(window).ready(function() {    
    var scroll = $(window).scrollTop();

     //>=, not <=
    if (scroll >= 20) {
        //clearHeader, not clearheader - caps H
        $(".main_menu").addClass("is_sticky");
        $(".main_menu").addClass("dy_background-gradient");
    }else
    {
        $(".main_menu").removeClass("is_sticky");
        $(".main_menu").removeClass("dy_background-gradient");
    }
}); 

// main_menu stiky end



// mobile menu
$(function () {
  'use strict'
  	window.onclick = function(event){
		if (document.getElementsByClassName('navbar-toggler')[0].contains(event.target)){
			$('.offcanvas-collapse').toggleClass('open')
		} else{
			$('.offcanvas-collapse').removeClass('open')
		}
	};
});

// mobile menu end

// menu scroll on id
$(document).ready(function () {
    $(document).on("scroll", onScroll);
    
    //smoothscroll
    $('.main_menu .nav-item a[href^="#"]').on('click', function (e) {
        e.preventDefault();
        $(document).off("scroll");
        
        $('.main_menu .nav-item a').each(function () {
            $(this).removeClass('active');
        })
        $(this).addClass('active');
      
        var target = this.hash,
            menu = target;
        $target = $(target);
        $('html, body').stop().animate({
            'scrollTop': $target.offset().top+2
        }, 500, 'swing', function () {
            window.location.hash = target;
            $(document).on("scroll", onScroll);
        });
    });
});

function onScroll(event){
    var scrollPos = $(document).scrollTop();
    $('.main_menu .nav-item a').each(function () {
        var currLink = $(this);
        var refElement = $(currLink.attr("href"));
        if (refElement.position().top <= scrollPos && refElement.position().top + refElement.height() > scrollPos) {
            $('.main_menu .nav-item a').removeClass("active");
            currLink.addClass("active");
        }
        else{
            currLink.removeClass("active");
        }
    });
}